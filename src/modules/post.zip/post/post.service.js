const autoBind = require("auto-bind");
const PostModel = require("./post.model");

class PostService {
  #model;
  constructor() {
    autoBind(this);
    this.#model = PostModel;
  }
  async getCategoryOption(categoryId) {
    const category = await this.#model.find({ category: categoryId });
    console.log(category);
    return category;
  }
}

module.exports = new PostService();
